from django.urls import path
from . import views
app_name='indexurl'

urlpatterns = [
    path('', views.myindex, name='index'),
    path('cybersecurity/', views.cybersecurity, name='cybersecurity'),
    path('softwaredevelopment/', views.softwaredev, name='softwaredevelopment'),
    path('webdevelopment/', views.webdev, name='webdevelopment'),
    path('codeacademy/', views.codeaca, name='codeacademy'),
    path('ai/', views.ai, name='ai'),
	
]