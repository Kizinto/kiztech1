from django.shortcuts import render, redirect, get_list_or_404, get_object_or_404
from django.http import HttpResponse, request
from .models import *
from django.contrib import messages
import random
from django.db.models import Q
from django.core.mail import EmailMessage,EmailMultiAlternatives
from django.conf import settings
from django.template.loader import render_to_string
import requests
from django.conf import settings 
from django.http.response import JsonResponse 
from django.views.decorators.csrf import csrf_exempt 
from django.views.generic.base import TemplateView


# Create your views here.

def myindex(request):	
	
	return render(request,'index.html',)

def cybersecurity(request):

	return render(request,'cybersecurity.html',)

def softwaredev(request):

	return render(request,'softwaredev.html',)

def webdev(request):

	return render(request,'webdev.html',)

def codeaca(request):

	return render(request,'codeaca.html',)

def ai(request):

	return render(request,'ai.html',)



